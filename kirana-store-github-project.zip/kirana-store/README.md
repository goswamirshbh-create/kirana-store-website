# 🛒 Mahalaxmi Flour & Kirana — Grocery Store Web App

A modern, mobile-first online grocery storefront for a local kirana shop, inspired by quick-commerce apps like Blinkit and Zepto. Customers browse products, build a cart and send the order straight to the shop on **WhatsApp**. The shop owner manages prices, stock and orders from a built-in admin panel.

> Built as a freelance-ready product: one HTML file for the front end, Supabase for the back end, zero build step.

**🔗 Live demo:** `https://<your-username>.github.io/<repo-name>/` *(add your link after enabling GitHub Pages)*

<!-- Add 2–3 screenshots: ![Home](screenshots/home.png) ![Cart](screenshots/cart.png) ![Admin](screenshots/admin.png) -->

## ✨ Features

**Customer side**
- 44 realistic grocery products in 9 categories, with search and category filters
- Discount badges (MRP vs. selling price), quantity stepper, persistent cart
- Free-delivery progress hint
- One-tap **WhatsApp ordering** with a pre-formatted order message
- Floating WhatsApp chat widget with quick-reply buttons
- Mobile OTP login (like Blinkit) when the backend is connected
- Responsive layout, light and dark mode, Hindi interface

**Owner side**
- Edit price / MRP, toggle in-stock status, add or delete products
- Change shop WhatsApp number, phone and free-delivery threshold
- Live orders list with status updates (new → confirmed → out for delivery → delivered)

## 🧱 Tech Stack

| Layer | Choice |
|---|---|
| Front end | Vanilla HTML, CSS, JavaScript (single file) |
| Back end | Supabase (PostgreSQL, Auth, Row Level Security) |
| Auth | Phone number + SMS OTP (Supabase Auth) |
| Hosting | GitHub Pages / Netlify / Vercel (static) |

## 🔐 Security Design
- Row Level Security on every table; only admins can write products and settings
- Orders can only be created through a `place_order()` database function, which **recalculates prices on the server**, so a customer cannot tamper with totals
- `is_admin` cannot be changed by users (column-level grants)
- Only the public `anon` key is used in the browser; never put a `service_role` key in the front end

## 🚀 Run It

**Demo mode (no setup):** open `index.html` in a browser. Products, cart and WhatsApp ordering work; the admin panel uses PIN `1234` and saves to your browser only.

**Full mode (with back end):**
1. Create a free project at [supabase.com](https://supabase.com).
2. In *SQL Editor*, run `supabase/schema.sql`. Set your own phone number as owner inside the file first.
3. Enable *Authentication → Providers → Phone* (use test OTPs while developing).
4. Copy the Project URL and anon key into the `CFG` line near the top of `index.html`.
5. Deploy the folder to GitHub Pages, Netlify or Vercel, and set the site URL in Supabase *Auth → URL Configuration*.

## 🗂 Project Structure
```
index.html          # complete storefront + admin panel
supabase/schema.sql # tables, RLS policies, place_order(), seed products
README.md
```

## 🛣 Roadmap
- Product photos and image upload
- UPI payment QR / payment links
- Customer "My Orders" page
- Multi-language (English, Gujarati)
- Order notifications to the owner

## 📄 License
MIT — see [LICENSE](LICENSE).
