-- =====================================================
-- महालक्ष्मी फ्लोर एंड किराना — Supabase Backend
-- Supabase Dashboard → SQL Editor → New query → पूरा paste → Run
-- =====================================================

create table if not exists settings(
  id int primary key default 1 check (id = 1),
  whatsapp text not null,
  phone text not null,
  free_delivery_min int not null default 499
);
insert into settings values (1, '919999999999', '+91 99999 99999', 499) on conflict do nothing;

create table if not exists profiles(
  id uuid primary key references auth.users on delete cascade,
  phone text,
  name text,
  address text,
  is_admin boolean not null default false,
  created_at timestamptz default now()
);

create table if not exists products(
  id bigint generated always as identity primary key,
  name text not null,
  unit text not null,
  category smallint not null,
  emoji text default '📦',
  price numeric(10,2) not null check (price >= 0),
  mrp numeric(10,2) not null check (mrp >= 0),
  in_stock boolean not null default true
);

create table if not exists orders(
  id bigint generated always as identity primary key,
  user_id uuid references auth.users,
  name text, phone text, address text,
  items jsonb not null,
  total numeric(10,2) not null,
  status text not null default 'new'
    check (status in ('new','confirmed','out_for_delivery','delivered','cancelled')),
  created_at timestamptz default now()
);

-- नया यूज़र लॉगिन करे तो profile अपने आप बने।
-- ⚠️ नीचे '919999999999' की जगह OWNER का नंबर (91 के साथ) डालें। वही admin बनेगा।
-- CHANGE '919999999999' below to the shop owner's phone number (with 91) before running.
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, phone, is_admin)
  values (new.id, new.phone, new.phone = '919999999999')
  on conflict do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

create or replace function is_admin() returns boolean
language sql security definer set search_path = public stable as $$
  select coalesce((select is_admin from profiles where id = auth.uid()), false)
$$;

-- ऑर्डर: दाम सर्वर खुद निकालता है (ग्राहक दाम बदल नहीं सकता)
create or replace function place_order(p_name text, p_phone text, p_address text, p_items jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare v_items jsonb; v_total numeric; v_id bigint;
begin
  if auth.uid() is null then raise exception 'login required'; end if;
  if jsonb_array_length(p_items) not between 1 and 100 then raise exception 'bad cart'; end if;
  select jsonb_agg(jsonb_build_object('product_id', p.id, 'name', p.name, 'unit', p.unit, 'price', p.price, 'qty', q.qty)),
         sum(p.price * q.qty)
    into v_items, v_total
    from jsonb_to_recordset(p_items) as q(product_id bigint, qty int)
    join products p on p.id = q.product_id
   where p.in_stock and q.qty between 1 and 50;
  if v_items is null then raise exception 'no valid items'; end if;
  insert into orders(user_id, name, phone, address, items, total)
  values (auth.uid(), left(p_name,80), left(p_phone,15), left(p_address,300), v_items, v_total)
  returning id into v_id;
  update profiles set name = left(p_name,80), address = left(p_address,300) where id = auth.uid();
  return v_id;
end $$;
revoke execute on function place_order(text,text,text,jsonb) from public, anon;
grant execute on function place_order(text,text,text,jsonb) to authenticated;

-- ===== सुरक्षा (Row Level Security) =====
alter table settings enable row level security;
alter table profiles enable row level security;
alter table products enable row level security;
alter table orders   enable row level security;

create policy "settings read"   on settings for select using (true);
create policy "settings admin"  on settings for update using (is_admin());

create policy "products read"   on products for select using (true);
create policy "products insert" on products for insert with check (is_admin());
create policy "products update" on products for update using (is_admin());
create policy "products delete" on products for delete using (is_admin());

create policy "profile read"    on profiles for select using (id = auth.uid() or is_admin());
create policy "profile update"  on profiles for update using (id = auth.uid());
revoke update on profiles from authenticated;
grant update (name, address) on profiles to authenticated;   -- is_admin कोई खुद नहीं बदल सकता

create policy "orders read"     on orders for select using (user_id = auth.uid() or is_admin());
create policy "orders status"   on orders for update using (is_admin());
-- orders में सीधा insert बंद है; सिर्फ़ place_order() से होगा।

-- ===== शुरुआती प्रोडक्ट =====
insert into products(name,unit,category,emoji,price,mrp) values
('गेहूँ चक्की आटा','5 किग्रा',0,'🌾',235,260),
('गेहूँ चक्की आटा','10 किग्रा',0,'🌾',455,500),
('बाजरा आटा','1 किग्रा',0,'🌽',48,55),
('बेसन','500 ग्राम',0,'🟡',62,70),
('सूजी (रवा)','500 ग्राम',0,'🥣',30,34),
('मैदा','1 किग्रा',0,'🍞',44,50),
('बासमती चावल (प्रीमियम)','1 किग्रा',0,'🍚',118,135),
('सोना मसूरी चावल','5 किग्रा',0,'🍚',310,350),
('पोहा (मोटा)','500 ग्राम',0,'🍥',34,40),
('अरहर दाल (तुअर)','1 किग्रा',1,'🫘',165,185),
('मूंग दाल धुली','1 किग्रा',1,'🫘',125,140),
('चना दाल','1 किग्रा',1,'🫘',98,110),
('मसूर दाल','1 किग्रा',1,'🫘',92,105),
('राजमा','500 ग्राम',1,'🫘',85,95),
('काबुली चना','500 ग्राम',1,'🧆',78,88),
('हल्दी पाउडर','200 ग्राम',2,'🟧',48,55),
('लाल मिर्च पाउडर','200 ग्राम',2,'🌶️',62,70),
('धनिया पाउडर','200 ग्राम',2,'🌿',42,48),
('गरम मसाला','100 ग्राम',2,'🧂',72,80),
('जीरा','100 ग्राम',2,'🌱',58,65),
('सरसों दाना','100 ग्राम',2,'⚫',14,18),
('सरसों तेल','1 लीटर',3,'🛢️',158,175),
('सोयाबीन रिफाइंड','1 लीटर',3,'🛢️',122,135),
('मूंगफली तेल','1 लीटर',3,'🥜',185,205),
('देसी घी','500 ml',3,'🧈',335,370),
('चीनी','1 किग्रा',4,'🍬',46,50),
('टाटा नमक','1 किग्रा',4,'🧂',28,30),
('गुड़ (देसी)','1 किग्रा',4,'🟤',65,75),
('मिश्री','250 ग्राम',4,'💎',38,45),
('पारले-जी बिस्कुट','पैक',5,'🍪',10,10),
('नमकीन (आलू भुजिया)','400 ग्राम',5,'🥨',95,110),
('मैगी नूडल्स','4 पैक',5,'🍜',56,60),
('मखाना','100 ग्राम',5,'⚪',95,110),
('चाय पत्ती (कड़क)','500 ग्राम',6,'🍵',245,270),
('इंस्टेंट कॉफी','100 ग्राम',6,'☕',285,310),
('फ्रूट जूस','1 लीटर',6,'🧃',105,115),
('अमूल दूध','500 ml',7,'🥛',33,33),
('पनीर (ताज़ा)','200 ग्राम',7,'🧀',78,85),
('अंडे','12 पीस',7,'🥚',84,95),
('अमूल बटर','100 ग्राम',7,'🧈',62,62),
('सर्फ़ एक्सेल (डिटर्जेंट)','1 किग्रा',8,'🧺',128,145),
('विम बार (बर्तन)','3 पीस',8,'🧽',30,36),
('टॉयलेट सोप','4 पैक',8,'🧼',118,140),
('अगरबत्ती','1 पैक',8,'🪔',35,40);
